# Atividade Django - Cadastro, Login e Lista de Produtos

## Como executar

```bash
python -m venv venv
# Windows: venv\Scripts\activate   |   Linux/Mac: source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Acesse: http://127.0.0.1:8000/

## Rotas

| Rota | Função |
|------|--------|
| `/cadastro/` | Cadastro (usuário, e-mail, senha, confirmar senha) -> redireciona para o login |
| `/login/` | Login -> redireciona para a página inicial; erro mostra mensagem |
| `/` | Página inicial (exige login; senão vai para o login) |
| `/produtos/adicionar/` | Adiciona produto (POST) |
| `/produtos/<id>/remover/` | Remove produto (POST) |
| `/logout/` | Logout (POST) -> redireciona para o login |
